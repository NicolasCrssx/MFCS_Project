#include <iostream>
#include "automaton.h"

using namespace std ;

int CheckAsynchronous(automaton A){ //Check if the automaton is asynchronous.

    int var ;

    for (int i = 0 ; i < A.nb_transitions ; i++ ){

        if (A.transitions[i].character == '*'){

            var = 1 ;

        }

    }

    return var ;

}



int FindStatePosition(automaton A,int state){ //Finds the position of a state in the array of the states.

    for (int i = 0 ; i < A.nb_states ; i++){

        if (A.states[i] == state){

            return i ;

        }

    }

}

void RemoveEpsilon(automaton &A){ //Delete the epsilon transitions of the array of the transitions

    for (int i = 0 ; i < A.nb_transitions ; i++){

        if (A.transitions[i].character == '*' ){

            if ( i == A.nb_transitions - 1 ){

                A.nb_transitions-- ;

            } else {

                A.transitions[i].source = A.transitions[A.nb_transitions-1].source ;
                A.transitions[i].character = A.transitions[A.nb_transitions-1].character ;
                A.transitions[i].target = A.transitions[A.nb_transitions-1].target ;
                A.nb_transitions -- ;
            }
        }
    }
}

int CheckIfTransitionAlreadyExists(automaton A,transition NewTransitions[100],int i,int j){ //Check if a transition already exists

    if (A.transitions[j].source == NewTransitions[i].source){

        if (A.transitions[j].character == NewTransitions[i].character){

            if (A.transitions[j].target == NewTransitions[i].target){

                return 1 ;
            }
        }
    }
    return 0 ;

}

void AddNewTransitions(automaton &A,transition NewTransitions[100],int nb3){ //Add a transition to the automaton


    for (int i = 0 ; i < nb3 ; i++){

        int val = 0 ;

        for (int j = 0 ; j < A.nb_transitions ; j++){

            val = val + CheckIfTransitionAlreadyExists(A,NewTransitions,i,j) ;

        }

        if (val == 0){
            A.transitions[A.nb_transitions].source = NewTransitions[i].source ;
            A.transitions[A.nb_transitions].character = NewTransitions[i].character ;
            A.transitions[A.nb_transitions].target = NewTransitions[i].target ;

            A.nb_transitions ++ ;
        }

    }

}

void DeleteEpsilonTransitions(automaton &A){ //Change the whole automaton so that it is not asynchronous anymore.

    transition NewTransitions[100];
    int nb3 = 0 ;

    for (int i = 0 ; i < A.nb_states ; i++ ){

        int CloseEpsilon[100];
        transition2 trans[100];
        int nb1 = 0 ;
        int nb2 = 0 ;
        CloseEpsilon[0] = A.states[i] ;
        nb1++ ;

        Eclose(A,CloseEpsilon,i,nb1);

        for (int j = 0 ; j < nb1 ; j++ ){

            for (int k = 0 ; k < A.nb_transitions ; k++){

                if (A.transitions[k].source == CloseEpsilon[j]){

                    if (A.transitions[k].character != '*'){

                        trans[nb2].state = A.transitions[k].target ;
                        trans[nb2].character = A.transitions[k].character ;
                        trans[nb2].EpsilonCloseTrans[trans[nb2].nb] = trans[nb2].state ;
                        trans[nb2].nb ++ ;
                        Eclose(A,trans[nb2].EpsilonCloseTrans,FindStatePosition(A,trans[nb2].state),trans[nb2].nb);
                        nb2++ ;
                    }
                }
            }
        }

        for (int j = 0 ; j < nb2 ; j++){

            for (int k = 0 ; k < trans[j].nb ; k++ ){

                NewTransitions[nb3].source = A.states[i] ;
                NewTransitions[nb3].character = trans[j].character ;
                NewTransitions[nb3].target = trans[j].EpsilonCloseTrans[k] ;
                nb3++ ;
            }
        }
    }

    int var = 0 ;

    while (var == 0){

        var = 1 ;

        RemoveEpsilon(A);

        for (int i = 0 ; i < A.nb_transitions ; i++){

            if (A.transitions[i].character == '*' ){

                var = 0 ;
            }
        }
    }

    AddNewTransitions(A,NewTransitions,nb3);

}


void Eclose(automaton A,int CloseEpsilon[100],int i,int &nb){ //Recursive function finding all the close epsilon transitions from a state.

    for (int j = 0 ; j < A.nb_transitions ; j++ ){

        if (A.states[i] == A.transitions[j].source){

            if (A.transitions[j].character == '*'){

                CloseEpsilon[nb] = A.transitions[j].target ;
                nb++ ;

                Eclose(A,CloseEpsilon,FindStatePosition(A,A.transitions[j].target),nb);

            }
        }
    }
}
