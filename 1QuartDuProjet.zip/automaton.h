#ifndef AUTOMATON_H_INCLUDED
#define AUTOMATON_H_INCLUDED

#include <fstream>

struct transition {

    int source ;
    int target ;
    char character ;

} ;

struct transition2 {

    int nb = 0 ;
    int state ;
    char character ;
    int EpsilonCloseTrans[100] ;

} ;

struct automaton {

    int language ;
    int nb_states ;
    int nb_init ;
    int nb_final ;
    int nb_transitions ;

    int init_states[100] ;
    int final_states[100] ;
    int states[100] ;

    transition transitions[100];

} ;


void getfile(char name[],automaton &A);

void display(automaton &A,int x, int y);

void gotoxy(int x, int y);

void CheckTransitions(int i, int j, automaton A,int &pos, int targets[100],int &nb);

void firstline(int x,int y,automaton A);

void InitOrFinal(int i,automaton A,int &pos,int x,int y);

void Separation(automaton A,int x,int y,int i,int var,int &pos);

void DisplayTargets(int i,int j, int pos, automaton A,int y);

int CheckAsynchronous(automaton A);

void DeleteEpsilonTransitions(automaton &A);

void Eclose(automaton A,int CloseEpsilon[100], int i,int &nb);

int FindStatePosition(automaton A,int state);

void RemoveEpsilon(automaton &A);

void AddNewTransitions(automaton &A,transition NewTransitions[100],int nb3);

int CheckIfTransitionAlreadyExists(automaton A,transition NewTransitions[100],int i,int j);

#endif // AUTOMATON_H_INCLUDED
