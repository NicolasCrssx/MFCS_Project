#include <iostream>
#include <fstream>
#include "automaton.h"

using namespace std;

void getfile (char name[],automaton &A){ //This function sends all the information about the automaton into a structure.

    ifstream file (name);
    file >> A.language ;
    file >> A.nb_states ;
    file >> A.nb_init ;
    for (int i = 0 ; i < A.nb_init ; i++){
        file >> A.init_states[i] ;
    }
    file >> A.nb_final ;
    for (int i = 0 ; i < A.nb_final ; i++){
        file >> A.final_states[i] ;
    }
    file >> A.nb_transitions ;
    for (int i = 0 ; i < A.nb_transitions ; i++){
        file >> A.transitions[i].source ;
        file >> A.transitions[i].character ;
        file >> A.transitions[i].target ;
    }

    int counter = 0 ;
    int k ;

    for (int i = 0 ; i < A.nb_transitions ; i++){
        int var = 0, j = 0 ;

        k = counter ;

        if (counter != 0){
            while ((var == 0)&&(j<k)){

                if (A.transitions[i].source == A.states[j]){
                    var = 1 ;
                }
                j++ ;
            }

            if (var == 0){
                A.states[counter] = A.transitions[i].source ;
                counter++ ;
            }
            var = 0 ;
            j = 0 ;
        } else {
            A.states[counter] = A.transitions[i].source ;
            counter++ ;
        }

        k = counter ;

        while ((var == 0)&&(j<k)){
            if (A.transitions[i].target == A.states[j]){
                var = 1 ;
            }
            j++ ;
        }

        if (var == 0){
            A.states[counter] = A.transitions[i].target ;
            counter++ ;
        }
        var = 0 ;
        j = 0 ;
    }


}

void display(automaton &A,int x,int y){ //Displays the transition table

    firstline(x,y,A);

    gotoxy(x,y+2);

    for (int i=0 ; i<A.nb_states ; i++){

        int pos = x + 3 ;
        gotoxy(pos,i*2+2+y) ;
        cout << A.states[i]  ;

        for (int j = 0 ; j < A.language ; j++){

            int nb = 0 ;
            int targets[100] ;
            pos = 14*(j+1) + x ;
            gotoxy(pos-1,i*2+2+y);
            cout << "|"  ;

            DisplayTargets(i,j,pos,A,y);

        }

        Separation(A,x,y,i,1,pos);

        pos = pos - 5 ;

        DisplayTargets(i,26,pos,A,y);

        Separation(A,x,y,i,2,pos);

        InitOrFinal(i,A,pos,x,y);


        gotoxy(x,i*2+3+y);

        cout << "--------------" ;
        for (int l = 0 ; l < A.language ; l++){
            cout << "--------------" ;
        }
        cout << "-------------------------" ;

    }


}

void firstline(int x,int y,automaton A){ //Writes the first line of the transition table

    gotoxy(x,y);
    char alphabet[28] = {"abcdefghijklmnopqrstuvwxyz*"} ;
    cout << " States      |      " ;
    for (int i = 0 ; i < A.language ; i++){
        cout << alphabet[i] << "      |      " ;
    }
    cout << "*      | " ;
    cout << "  I/F ?  |"  ;
    gotoxy(x,y+1);
    cout << "--------------" ;
    for (int i = 0 ; i < A.language ; i++){
        cout << "--------------" ;
    }
    cout << "-------------------------" ;

}

void DisplayTargets(int i,int j, int pos, automaton A,int y){ // Gets all the targets and displays it in a proper way.

    int targets[100] ;
    int nb = 0  ;

    CheckTransitions(i,j,A,pos,targets,nb);

    int place = 0 ;
    for (int k = 0 ; k < nb ; k++){

        int n = targets[k] ;
        int cnt = 0;
        while (n != 0) {
            n = n / 10;
            ++cnt;
        }
        place = place + cnt+1 ;
    }


    if ((place == 2)||(place == 0)||(place == 1)){
        gotoxy(pos+6,i*2+2+y);
    } else if ((place == 2)||(place == 3)){
        gotoxy(pos+5,i*2+2+y);
    } else if ((place == 4)||(place == 5)){
        gotoxy(pos+4,i*2+2+y);
    } else if ((place == 6)||(place == 7)){
        gotoxy(pos+3,i*2+2+y);
    } else if ((place == 8)||(place == 9)){
        gotoxy(pos+2,i*2+2+y);
    } else if ((place == 10)||(place == 11)){
        gotoxy(pos+1,i*2+2+y);
    } else {
        gotoxy(pos,i*2+2+y);
    }



    for (int k = 0 ; k < nb ; k++){

        cout << targets[k] << "." ;
    }

}

void CheckTransitions(int i, int j, automaton A,int &pos,int targets[100],int &nb){ //Checks all the transitions and see if one corresponds.

    char alphabet[28] = {"abcdefghijklmnopqrstuvwxyz*"} ;

    for (int k = 0 ; k<A.nb_transitions ; k++ ){
        if (A.transitions[k].source == A.states[i] ){
            if (A.transitions[k].character == alphabet[j]){
                targets[nb] = A.transitions[k].target ;
                nb++ ;
            }
        }
    }
}

void InitOrFinal(int i,automaton A,int &pos,int x,int y){ //Checks if a state is initial or terminal or both.

        int init = 0 , term = 0 ;

        for (int j = 0 ; j < A.nb_init ; j++){
            if (A.init_states[j] == A.states[i]){
                init = 1 ;
            }
        }
        for (int j = 0 ; j < A.nb_final ; j++){
            if (A.final_states[j] == A.states[i]){
                term = 1 ;
            }
        }

        if ((init == 1)&&(term == 1)){
            pos = pos - 2  ;
            gotoxy(pos,i*2+2+y);
            printf("I/F");
        } else {
            gotoxy(pos-1,i*2+2+y);
            if ((init == 1)&&(term == 0)){
                printf("I");
            }
            if ((init == 0)&&(term == 1)){
                printf("F");
            }
        }
        pos = 14*(A.language+3) + x - 3 ;
        gotoxy(pos-1,i*2+2+y);
        cout << "|" ;
}

void Separation(automaton A,int x,int y,int i,int var,int &pos){ //Create a line with the right number of '-' ;

        pos = 14*(A.language+var) + x ;
        gotoxy(pos-1,i*2+2+y);
        cout << "|" ;
        pos = pos + 5 ;
        gotoxy(pos,i*2+2+y);
}
