#include <iostream>
#include <fstream>
#include <windows.h>
#include "automaton.h"

using namespace std;

 int main() {

    char filename[20] = {"Int1-3-2.txt"} ;

    automaton A ;

    getfile(filename,A) ;

    gotoxy(0,0);
    cout << "Table of transitions of the automaton : " ;

    display(A,5,2);

    if (CheckAsynchronous(A) == 1 ){

        DeleteEpsilonTransitions(A);

        gotoxy(0,16);

        cout << "Table of transitions after removing epsilon transitions : " ;

        display(A,5,18);

    }



    display(A,5,18);


    cout << endl << endl ;


    return 0 ;

}

